import { useState } from "react";

const FONT_LINK = "https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@300;400;500;600;700&display=swap";

// ── Brand Colors (from invoice) ────────────────────────────────────────────
const B = {
  navy:      "#1e2d4a",
  navyDark:  "#162239",
  navyLight: "#253757",
  gold:      "#c9a84c",
  goldLight: "#e8d5a3",
  cream:     "#f5f0e8",
  creamDark: "#ede5d4",
  white:     "#ffffff",
  text:      "#1e2d4a",
  textMid:   "#4a5568",
  textLight: "#8892a4",
  border:    "#d8ccb4",
  rowAlt:    "#f9f6f0",
};

const VENDORS = {
  "Mowing & Landscaping": [
    { name: "Carlos", role: "Mowing", phone: "(615) 983-0566" },
    { name: "Blake", role: "Landscaping – Beds, plantings, trimming", phone: "(615) 587-7368" },
  ],
  "HVAC": [
    { name: "Comfort Systems – Abe", role: "General HVAC", phone: "(615) 405-5901" },
    { name: "Copeland Home Services", role: "General HVAC", phone: "(615) 244-9520" },
    { name: "Heritage Heating & Cooling – Jeff", role: "General HVAC", phone: "(615) 394-6000" },
    { name: "C&M Heating and Cooling – Daniel Sullivan", role: "Geothermal", phone: "(615) 790-1362" },
  ],
  "Plumbing": [
    { name: "Joe", role: "Plumbing", phone: "(615) 302-4743" },
    { name: "Joslin Heating and Cooling", role: "Plumbing", phone: "(615) 794-7707" },
  ],
  "Pest Control": [
    { name: "Arrow Exterminators – Brandon Cole", role: "Pest Control", phone: "(615) 476-8337" },
  ],
  "Pool": [
    { name: "TN Pool Covers – Adam", role: "Cover install & troubleshooting", phone: "(615) 502-7000" },
  ],
  "Security / Network": [
    { name: "Symspire", role: "Security & AV – Text Line", phone: "(615) 981-2148" },
  ],
  "Propane & Gas": [
    { name: "Holston Gases – Mike Todd", role: "Propane & Gas", phone: "(615) 829-1509" },
  ],
  "Local Contacts": [
    { name: "Caitlyn Comaroto", role: "Realtor's Assistant", phone: "(615) 485-5333" },
    { name: "Jake", role: "Semler Manager (Neighbor)", phone: "(615) 478-5968" },
  ],
};

const AUDIT_SECTIONS = [
  { id: "restock",   label: "Restock – Guest & Kitchen", icon: "🛒", items: ["Soft drinks (Sprite, Coke, Dr. Pepper, Diet options)","Greek Yogurt","Hummus / Pretzels","Bananas","Apples","Cranberry Juice","Canned Coffee","Fresh Berries (strawberries, blueberries, raspberries)","All guest fridges fully stocked"] },
  { id: "fireplace", label: "Fireplace",                  icon: "🔥", items: ["Guest porch fireplace cleaned","Main house fireplace cleaned","Firewood available","Fireplace area clean"] },
  { id: "cleaning",  label: "Cleaning Services",          icon: "🧹", items: ["Cleaning service visited property","Post-guest cleaning completed","Confirm next scheduled visit"] },
  { id: "plumbing",  label: "Faucets & Plumbing",         icon: "🚿", items: ["Check all faucets for drips/leaks","Toilets checked and operational","Repairs referred to subcontractor if needed"] },
  { id: "fridges",   label: "Fridges",                    icon: "❄️", items: ["All fridges cleaned after guest departure","Expired items removed","No spoiled food present"] },
  { id: "garden",    label: "Garden & Grounds",           icon: "🌿", items: ["Garden in order","Dead plants identified","Weeds pulled","Plant replacements ordered if needed"] },
  { id: "garage",    label: "Garage & Vehicles",          icon: "🚗", items: ["All vehicles operational","All vehicles fueled","Garage free of dust and leaves","Garage organized"] },
  { id: "inventory", label: "Inventory",                  icon: "📦", items: ["Garage cabinet inventory checked","Supplies replenished before depletion"] },
  { id: "pool",      label: "Pool",                       icon: "🏊", items: ["Pool water clean","Pool cover functioning properly"] },
  { id: "pond",      label: "Pond",                       icon: "🐟", items: ["Both pond fountains working","Pond appearance meets standard"] },
  { id: "gate",      label: "Front Gate",                 icon: "🚪", items: ["Gate system operational","Access system confirmed","Access instructions verified"] },
  { id: "mowing",    label: "Mowing & Landscaping",       icon: "🌾", items: ["Mowing schedule confirmed","Growth controlled","Winter cutback plan in place"] },
  { id: "roads",     label: "Roads & Driveways",          icon: "🛤️", items: ["Chip seal / pea gravel condition checked","Holes or washouts filled","Quotes gathered if needed"] },
  { id: "lanterns",  label: "Lanterns",                   icon: "🏮", items: ["Gas lantern maintenance reviewed","Troubleshooting plan confirmed"] },
  { id: "steps",     label: "Steps & Entryways",          icon: "🚶", items: ["All steps clean and presentable","Inspected after rain"] },
  { id: "ac",        label: "AC Units",                   icon: "🌡️", items: ["Monthly AC operational checks complete","Thermostats set correctly"] },
  { id: "games",     label: "Games",                      icon: "🎯", items: ["Shuffleboard sanded","Game equipment operational"] },
  { id: "av",        label: "TV & Control Systems",       icon: "📺", items: ["Symspire status confirmed","TV picture and volume synced","Control4 panel operational"] },
];

const TOTAL_ITEMS = AUDIT_SECTIONS.reduce((s, sec) => s + sec.items.length, 0);

const SEED_WOS = [
  { id: "WO-001", category: "HVAC",                 description: "Spring geothermal system service",              vendor: "C&M Heating and Cooling – Daniel Sullivan", priority: "Scheduled", status: "Complete",    cost: 480, date: "2025-02-15", notes: "" },
  { id: "WO-002", category: "Pool",                 description: "Pool cover inspection and adjustment",          vendor: "TN Pool Covers – Adam",                     priority: "Standard",  status: "Complete",    cost: 150, date: "2025-02-22", notes: "" },
  { id: "WO-003", category: "Mowing & Landscaping", description: "Spring bed prep – dead plants replaced",       vendor: "Blake – Landscaping",                       priority: "Standard",  status: "In Progress", cost: 620, date: "2025-03-01", notes: "Waiting on replacement plantings" },
  { id: "WO-004", category: "Pest Control",         description: "Quarterly pest treatment – all structures",    vendor: "Arrow Exterminators – Brandon Cole",        priority: "Scheduled", status: "Pending",     cost: 195, date: "2025-03-10", notes: "" },
  { id: "WO-005", category: "Security / Network",   description: "Control4 panel sync issue – Symspire onsite", vendor: "Symspire",                                  priority: "Urgent",    status: "Pending",     cost: 0,   date: "2025-03-03", notes: "TV volume not responding" },
];

const STATUS_STYLES = {
  "Complete":    { bg: "#e8f5e9", color: "#2e7d32", border: "#a5d6a7" },
  "In Progress": { bg: "#e3f0fb", color: "#1565c0", border: "#90caf9" },
  "Pending":     { bg: "#fff8e1", color: "#b45309", border: "#fde68a" },
  "Urgent":      { bg: "#fdecea", color: "#b71c1c", border: "#ef9a9a" },
};
const PRIORITY_STYLES = {
  "Scheduled": { bg: B.cream,    color: B.textMid,  border: B.border  },
  "Standard":  { bg: "#e3f0fb",  color: "#1565c0",  border: "#90caf9" },
  "Urgent":    { bg: "#fdecea",  color: "#b71c1c",  border: "#ef9a9a" },
  "Emergency": { bg: "#fdecea",  color: "#7f0000",  border: "#ef9a9a" },
};

function Badge({ label, styleMap }) {
  const s = styleMap?.[label] || { bg: B.cream, color: B.textMid, border: B.border };
  return (
    <span style={{ background: s.bg, color: s.color, border: `1px solid ${s.border}`, borderRadius: 4, padding: "2px 10px", fontSize: 11, fontWeight: 700, letterSpacing: "0.05em", whiteSpace: "nowrap", display: "inline-block" }}>
      {label.toUpperCase()}
    </span>
  );
}

function SectionHeader({ children }) {
  return (
    <div style={{ background: B.navy, color: B.goldLight, padding: "8px 16px", fontSize: 11, fontWeight: 700, letterSpacing: "0.12em" }}>
      {typeof children === "string" ? children.toUpperCase() : children}
    </div>
  );
}

function Card({ children, style = {} }) {
  return (
    <div style={{ background: B.white, border: `1px solid ${B.border}`, borderRadius: 8, overflow: "hidden", boxShadow: "0 1px 4px rgba(30,45,74,0.07)", ...style }}>
      {children}
    </div>
  );
}

function Logo({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <rect width="48" height="48" rx="5" fill={B.navyDark} />
      <polyline points="8,27 24,11 40,27" stroke={B.gold} strokeWidth="2.5" strokeLinejoin="round" fill="none" />
      <rect x="13" y="27" width="22" height="13" stroke={B.gold} strokeWidth="2" fill="none" />
      <rect x="20" y="32" width="8" height="8" stroke={B.gold} strokeWidth="1.5" fill="none" />
      <rect x="30" y="15" width="4" height="8" stroke={B.gold} strokeWidth="1.5" fill="none" />
    </svg>
  );
}

function TopBar({ tab, setTab }) {
  const tabs = [
    { id: "dashboard",   label: "Overview" },
    { id: "properties",  label: "Properties" },
    { id: "audit",       label: "Monthly Audit" },
    { id: "workorders",  label: "Work Orders" },
    { id: "vendors",     label: "Vendors" },
  ];
  return (
    <div style={{ background: B.navy, borderBottom: `3px solid ${B.gold}` }}>
      <div style={{ display: "flex", alignItems: "center", padding: "14px 32px", gap: 14 }}>
        <Logo size={42} />
        <div>
          <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: B.white, fontWeight: 700, lineHeight: 1.1 }}>StonePoint Management</div>
          <div style={{ fontSize: 11, color: B.gold, fontWeight: 500, letterSpacing: "0.1em", marginTop: 2 }}>YOUR PROPERTY, OUR PRIORITY</div>
        </div>
        <div style={{ marginLeft: "auto", textAlign: "right" }}>
          <div style={{ fontSize: 13, color: B.goldLight, fontWeight: 600 }}>3385 Bailey Rd</div>
          <div style={{ fontSize: 11, color: "#8899bb", marginTop: 1 }}>Leipers Fork, TN</div>
        </div>
      </div>
      <div style={{ display: "flex", padding: "0 32px" }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{ background: "none", border: "none", borderBottom: tab === t.id ? `3px solid ${B.gold}` : "3px solid transparent", color: tab === t.id ? B.goldLight : "#8899bb", padding: "10px 20px 8px", cursor: "pointer", fontSize: 13, fontWeight: tab === t.id ? 700 : 400, fontFamily: "'Inter', sans-serif", marginBottom: -3, transition: "color 0.15s" }}>
            {t.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function PageLabel({ sub, title }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ fontSize: 11, color: B.gold, fontWeight: 700, letterSpacing: "0.12em" }}>{sub}</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 24, color: B.navy, fontWeight: 700 }}>{title}</div>
    </div>
  );
}

// ── DASHBOARD ──────────────────────────────────────────────────────────────
function DashboardTab() {
  const openWOs = SEED_WOS.filter(w => w.status !== "Complete").length;
  const urgentWOs = SEED_WOS.filter(w => w.priority === "Urgent" || w.priority === "Emergency").length;
  const totalVendors = Object.values(VENDORS).flat().length;
  const month = new Date().toLocaleString("default", { month: "long", year: "numeric" });

  return (
    <div>
      {/* Property banner */}
      <div style={{ background: B.navy, borderRadius: 8, padding: "16px 24px", marginBottom: 24, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: 11, color: B.gold, fontWeight: 700, letterSpacing: "0.12em", marginBottom: 4 }}>PROPERTY OVERVIEW</div>
          <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 26, color: B.white, fontWeight: 700 }}>3385 Bailey Rd</div>
          <div style={{ fontSize: 12, color: "#8899bb", marginTop: 2 }}>Leipers Fork, TN · Managed by StonePoint</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 11, color: B.gold, fontWeight: 700, letterSpacing: "0.1em", marginBottom: 4 }}>REPORTING PERIOD</div>
          <div style={{ fontSize: 15, color: B.goldLight, fontWeight: 600 }}>{month}</div>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 24 }}>
        {[
          { label: "Audit Items",       value: TOTAL_ITEMS, sub: "to inspect monthly",   color: B.navy },
          { label: "Open Work Orders",  value: openWOs,     sub: "active this month",     color: B.gold },
          { label: "Urgent Items",      value: urgentWOs,   sub: "need attention",        color: urgentWOs > 0 ? "#b71c1c" : B.textLight },
          { label: "Vendors on File",   value: totalVendors,sub: "approved contacts",     color: B.navy },
        ].map(({ label, value, sub, color }) => (
          <div key={label} style={{ background: B.white, border: `1px solid ${B.border}`, borderRadius: 8, padding: "18px 20px", boxShadow: "0 1px 4px rgba(30,45,74,0.07)" }}>
            <div style={{ fontSize: 34, fontWeight: 700, color, fontFamily: "'Playfair Display', serif", lineHeight: 1 }}>{value}</div>
            <div style={{ fontSize: 11, color: B.textLight, marginTop: 2 }}>{sub}</div>
            <div style={{ fontSize: 12, color: B.textMid, marginTop: 6, fontWeight: 500 }}>{label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
        <Card>
          <SectionHeader>Recent Work Orders</SectionHeader>
          {SEED_WOS.map((w, i) => (
            <div key={w.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 16px", background: i % 2 === 0 ? B.white : B.rowAlt, borderBottom: i < SEED_WOS.length - 1 ? `1px solid ${B.border}` : "none" }}>
              <div>
                <div style={{ fontSize: 13, color: B.text, fontWeight: 500 }}>{w.description}</div>
                <div style={{ fontSize: 11, color: B.textLight, marginTop: 2 }}>{w.category} · {w.date}</div>
              </div>
              <Badge label={w.status} styleMap={STATUS_STYLES} />
            </div>
          ))}
        </Card>

        <Card>
          <SectionHeader>Quick Contacts</SectionHeader>
          {[
            { name: "Carlos – Mowing",              phone: "(615) 983-0566" },
            { name: "Blake – Landscaping",           phone: "(615) 587-7368" },
            { name: "Symspire – AV/Security",        phone: "(615) 981-2148" },
            { name: "Arrow Exterminators – Brandon", phone: "(615) 476-8337" },
            { name: "C&M HVAC – Daniel Sullivan",    phone: "(615) 790-1362" },
            { name: "TN Pool Covers – Adam",         phone: "(615) 502-7000" },
            { name: "Holston Gases – Mike Todd",     phone: "(615) 829-1509" },
          ].map(({ name, phone }, i) => (
            <div key={phone} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 16px", background: i % 2 === 0 ? B.white : B.rowAlt, borderBottom: `1px solid ${B.border}` }}>
              <span style={{ fontSize: 13, color: B.text }}>{name}</span>
              <a href={`tel:${phone}`} style={{ fontSize: 13, color: B.gold, textDecoration: "none", fontWeight: 700 }}>{phone}</a>
            </div>
          ))}
        </Card>
      </div>

      <Card>
        <SectionHeader>Monthly Audit — All Sections ({AUDIT_SECTIONS.length})</SectionHeader>
        <div style={{ padding: 16, display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(190px, 1fr))", gap: 8 }}>
          {AUDIT_SECTIONS.map((sec, i) => (
            <div key={sec.id} style={{ background: i % 2 === 0 ? B.cream : B.white, border: `1px solid ${B.border}`, borderRadius: 6, padding: "10px 14px", display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 15 }}>{sec.icon}</span>
              <span style={{ fontSize: 12, color: B.text, fontWeight: 500, lineHeight: 1.3 }}>{sec.label}</span>
            </div>
          ))}
        </div>
      </Card>

      <div style={{ marginTop: 24, padding: "12px 0", borderTop: `1px solid ${B.border}`, display: "flex", justifyContent: "space-between" }}>
        <span style={{ fontSize: 11, color: B.textLight }}>StonePoint Management · Your Property, Our Priority</span>
        <span style={{ fontSize: 11, color: B.textLight }}>Confidential</span>
      </div>
    </div>
  );
}

// ── AUDIT ──────────────────────────────────────────────────────────────────
function AuditTab() {
  const now = new Date();
  const [month, setMonth] = useState(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`);
  const [inspector, setInspector] = useState("");
  const [checks, setChecks] = useState({});
  const [notes, setNotes] = useState({});
  const [followUp, setFollowUp] = useState(false);
  const [nextReview, setNextReview] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const toggle = (secId, idx) => setChecks(p => ({ ...p, [`${secId}-${idx}`]: !p[`${secId}-${idx}`] }));
  const checked = (secId, idx) => !!checks[`${secId}-${idx}`];
  const totalChecked = Object.values(checks).filter(Boolean).length;
  const pct = Math.round((totalChecked / TOTAL_ITEMS) * 100);
  const secPct = (sec) => Math.round((sec.items.filter((_, i) => checked(sec.id, i)).length / sec.items.length) * 100);

  if (submitted) {
    return (
      <div style={{ maxWidth: 520, margin: "50px auto" }}>
        <Card>
          <SectionHeader>Audit Submitted — 3385 Bailey Rd</SectionHeader>
          <div style={{ padding: 32, textAlign: "center" }}>
            <div style={{ width: 52, height: 52, borderRadius: "50%", background: "#e8f5e9", border: "2px solid #a5d6a7", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", fontSize: 22, color: "#2e7d32" }}>✓</div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 24, color: B.navy, marginBottom: 6 }}>Audit Complete</div>
            <p style={{ color: B.textMid, fontSize: 13, margin: "0 0 16px" }}>3385 Bailey Rd · {month} · Inspector: {inspector || "—"}</p>
            <div style={{ background: B.cream, border: `1px solid ${B.border}`, borderRadius: 6, padding: "12px 20px", display: "inline-block", marginBottom: 14 }}>
              <span style={{ fontSize: 26, fontWeight: 700, color: B.navy, fontFamily: "'Playfair Display', serif" }}>{pct}%</span>
              <span style={{ fontSize: 13, color: B.textMid, marginLeft: 10 }}>{totalChecked} / {TOTAL_ITEMS} items</span>
            </div>
            {followUp && (
              <div style={{ background: "#fff8e1", border: "1px solid #fde68a", borderRadius: 6, padding: "10px 16px", fontSize: 13, color: "#92400e", marginBottom: 14 }}>
                ⚠ Follow-up required · Next review: {nextReview || "TBD"}
              </div>
            )}
            <button onClick={() => { setSubmitted(false); setChecks({}); setNotes({}); setFollowUp(false); setNextReview(""); }}
              style={{ background: B.navy, color: B.goldLight, border: "none", borderRadius: 6, padding: "11px 28px", fontWeight: 700, cursor: "pointer", fontSize: 14 }}>
              Start New Audit
            </button>
          </div>
          <div style={{ padding: "10px 16px", borderTop: `1px solid ${B.border}`, display: "flex", justifyContent: "space-between" }}>
            <span style={{ fontSize: 11, color: B.textLight }}>StonePoint Management · Your Property, Our Priority</span>
            <span style={{ fontSize: 11, color: B.textLight }}>Confidential</span>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <Card style={{ marginBottom: 20 }}>
        <SectionHeader>Monthly Property Audit Checklist — 3385 Bailey Rd</SectionHeader>
        <div style={{ padding: "16px 20px", background: B.cream, display: "flex", gap: 24, flexWrap: "wrap", alignItems: "flex-end" }}>
          <div>
            <label style={{ fontSize: 11, color: B.gold, display: "block", marginBottom: 4, fontWeight: 700, letterSpacing: "0.1em" }}>MONTH / YEAR</label>
            <input type="month" value={month} onChange={e => setMonth(e.target.value)} style={{ background: B.white, border: `1px solid ${B.border}`, borderRadius: 6, padding: "7px 12px", color: B.text, fontSize: 13, fontFamily: "'Inter', sans-serif" }} />
          </div>
          <div>
            <label style={{ fontSize: 11, color: B.gold, display: "block", marginBottom: 4, fontWeight: 700, letterSpacing: "0.1em" }}>INSPECTOR</label>
            <input placeholder="Your name" value={inspector} onChange={e => setInspector(e.target.value)} style={{ background: B.white, border: `1px solid ${B.border}`, borderRadius: 6, padding: "7px 12px", color: B.text, fontSize: 13, width: 200, fontFamily: "'Inter', sans-serif" }} />
          </div>
          <div style={{ marginLeft: "auto", textAlign: "right" }}>
            <div style={{ fontSize: 11, color: B.gold, fontWeight: 700, letterSpacing: "0.1em", marginBottom: 4 }}>PROGRESS</div>
            <div style={{ fontSize: 30, fontWeight: 700, color: B.navy, fontFamily: "'Playfair Display', serif", lineHeight: 1 }}>{pct}%</div>
            <div style={{ fontSize: 11, color: B.textLight }}>{totalChecked} of {TOTAL_ITEMS} items</div>
          </div>
        </div>
        <div style={{ height: 5, background: B.creamDark }}>
          <div style={{ height: 5, width: `${pct}%`, background: pct === 100 ? "#2e7d32" : B.gold, transition: "width 0.3s" }} />
        </div>
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16, marginBottom: 24 }}>
        {AUDIT_SECTIONS.map(sec => {
          const sp = secPct(sec);
          const done = sp === 100;
          return (
            <Card key={sec.id}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 16px", background: done ? "#e8f5e9" : B.cream, borderBottom: `1px solid ${B.border}` }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span>{sec.icon}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: B.navy }}>{sec.label}</span>
                </div>
                <span style={{ fontSize: 12, fontWeight: 700, color: done ? "#2e7d32" : B.gold }}>{sp}%</span>
              </div>
              <div style={{ padding: "12px 16px" }}>
                {sec.items.map((item, i) => (
                  <label key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, marginBottom: 9, cursor: "pointer" }}>
                    <div onClick={() => toggle(sec.id, i)} style={{ width: 17, height: 17, minWidth: 17, borderRadius: 4, border: `2px solid ${checked(sec.id, i) ? "#2e7d32" : B.border}`, background: checked(sec.id, i) ? "#2e7d32" : B.white, display: "flex", alignItems: "center", justifyContent: "center", marginTop: 1, cursor: "pointer", transition: "all 0.15s" }}>
                      {checked(sec.id, i) && <span style={{ color: "#fff", fontSize: 10, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                    </div>
                    <span onClick={() => toggle(sec.id, i)} style={{ fontSize: 13, color: checked(sec.id, i) ? B.textLight : B.text, textDecoration: checked(sec.id, i) ? "line-through" : "none", lineHeight: 1.45, userSelect: "none" }}>
                      {item}
                    </span>
                  </label>
                ))}
                <textarea placeholder="Notes…" value={notes[sec.id] || ""} onChange={e => setNotes(p => ({ ...p, [sec.id]: e.target.value }))} rows={2}
                  style={{ width: "100%", background: B.cream, border: `1px solid ${B.border}`, borderRadius: 5, padding: "6px 10px", color: B.text, fontSize: 12, resize: "none", boxSizing: "border-box", fontFamily: "'Inter', sans-serif", marginTop: 4 }} />
              </div>
            </Card>
          );
        })}
      </div>

      <Card style={{ marginBottom: 20 }}>
        <SectionHeader>Overall Issues / Summary Notes</SectionHeader>
        <div style={{ padding: 16, background: B.cream }}>
          <textarea placeholder="Overall issues or summary notes for this inspection…" value={notes["_summary"] || ""} onChange={e => setNotes(p => ({ ...p, _summary: e.target.value }))} rows={3}
            style={{ width: "100%", background: B.white, border: `1px solid ${B.border}`, borderRadius: 6, padding: "10px 12px", color: B.text, fontSize: 14, resize: "vertical", boxSizing: "border-box", fontFamily: "'Inter', sans-serif" }} />
          <div style={{ display: "flex", gap: 32, marginTop: 14, flexWrap: "wrap", alignItems: "center" }}>
            <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}>
              <div onClick={() => setFollowUp(!followUp)} style={{ width: 17, height: 17, borderRadius: 4, border: `2px solid ${followUp ? B.gold : B.border}`, background: followUp ? "#fff8e1" : B.white, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
                {followUp && <span style={{ color: B.gold, fontSize: 10, fontWeight: 900 }}>✓</span>}
              </div>
              <span style={{ fontSize: 13, color: B.text, fontWeight: 500 }}>Follow-Up Required</span>
            </label>
            <div>
              <label style={{ fontSize: 11, color: B.gold, display: "block", marginBottom: 4, fontWeight: 700, letterSpacing: "0.08em" }}>NEXT REVIEW DATE</label>
              <input type="date" value={nextReview} onChange={e => setNextReview(e.target.value)} style={{ background: B.white, border: `1px solid ${B.border}`, borderRadius: 6, padding: "6px 10px", color: B.text, fontSize: 13, fontFamily: "'Inter', sans-serif" }} />
            </div>
          </div>
        </div>
      </Card>

      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
        <button onClick={() => setSubmitted(true)} style={{ background: B.navy, color: B.goldLight, border: "none", borderRadius: 6, padding: "13px 32px", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
          Submit Audit — {pct}% Complete
        </button>
        <span style={{ fontSize: 12, color: B.textLight }}>Manager Signature required on submission</span>
      </div>
    </div>
  );
}

// ── WORK ORDERS ────────────────────────────────────────────────────────────
function WorkOrdersTab() {
  const [wos, setWos] = useState(SEED_WOS);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ category: "HVAC", description: "", vendor: "", priority: "Standard", cost: "", notes: "" });
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const updateStatus = (id, status) => setWos(prev => prev.map(w => w.id === id ? { ...w, status } : w));
  const allVendorNames = Object.values(VENDORS).flat().map(v => v.name);
  const categories = ["HVAC","Plumbing","Mowing & Landscaping","Pest Control","Pool","Security / Network","Propane & Gas","Cleaning","General Repair","Other"];

  const addWO = () => {
    if (!form.description) return;
    const id = `WO-${String(wos.length + 1).padStart(3, "0")}`;
    setWos(p => [...p, { ...form, id, status: "Pending", date: new Date().toISOString().slice(0, 10), cost: +form.cost || 0 }]);
    setShowForm(false);
    setForm({ category: "HVAC", description: "", vendor: "", priority: "Standard", cost: "", notes: "" });
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 20 }}>
        <PageLabel sub="3385 BAILEY RD" title="Work Orders" />
        <button onClick={() => setShowForm(true)} style={{ background: B.navy, color: B.goldLight, border: "none", borderRadius: 6, padding: "10px 22px", fontWeight: 700, cursor: "pointer", fontSize: 14, marginBottom: 4 }}>+ New Work Order</button>
      </div>

      <Card>
        <SectionHeader>Active & Recent Work Orders</SectionHeader>
        <div style={{ display: "grid", gridTemplateColumns: "90px 1fr 170px 90px 130px 80px", gap: 10, padding: "8px 16px", background: B.navyDark, color: B.goldLight, fontSize: 11, fontWeight: 700, letterSpacing: "0.08em" }}>
          <div>WO #</div><div>DESCRIPTION</div><div>VENDOR</div><div>PRIORITY</div><div>STATUS</div><div style={{ textAlign: "right" }}>COST</div>
        </div>
        {wos.map((w, i) => (
          <div key={w.id} style={{ display: "grid", gridTemplateColumns: "90px 1fr 170px 90px 130px 80px", gap: 10, padding: "12px 16px", background: i % 2 === 0 ? B.white : B.rowAlt, borderBottom: `1px solid ${B.border}`, alignItems: "start" }}>
            <div>
              <div style={{ fontSize: 11, fontFamily: "monospace", color: B.gold, fontWeight: 700 }}>{w.id}</div>
              <div style={{ fontSize: 10, color: B.textLight, marginTop: 2 }}>{w.date}</div>
            </div>
            <div>
              <div style={{ fontSize: 13, color: B.text, fontWeight: 500 }}>{w.description}</div>
              <div style={{ fontSize: 11, color: B.textLight, marginTop: 2 }}>{w.category}{w.notes ? ` · ${w.notes}` : ""}</div>
            </div>
            <div style={{ fontSize: 12, color: B.textMid, lineHeight: 1.3 }}>{w.vendor || "—"}</div>
            <div><Badge label={w.priority} styleMap={PRIORITY_STYLES} /></div>
            <div>
              <Badge label={w.status} styleMap={STATUS_STYLES} />
              <select value={w.status} onChange={e => updateStatus(w.id, e.target.value)}
                style={{ marginTop: 6, display: "block", background: B.cream, border: `1px solid ${B.border}`, borderRadius: 4, padding: "2px 6px", color: B.textMid, fontSize: 10, cursor: "pointer", width: "100%", fontFamily: "'Inter', sans-serif" }}>
                <option>Pending</option><option>In Progress</option><option>Complete</option>
              </select>
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: B.navy, textAlign: "right" }}>{w.cost > 0 ? `$${w.cost.toLocaleString()}` : "—"}</div>
          </div>
        ))}
        <div style={{ padding: "10px 16px", background: B.cream, display: "flex", justifyContent: "flex-end", borderTop: `1px solid ${B.border}` }}>
          <span style={{ fontSize: 12, color: B.gold, fontWeight: 700, letterSpacing: "0.08em" }}>
            TOTAL: ${wos.reduce((s, w) => s + w.cost, 0).toLocaleString()}
          </span>
        </div>
      </Card>

      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "#00000088", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999 }}>
          <div style={{ background: B.white, border: `1px solid ${B.border}`, borderRadius: 8, overflow: "hidden", width: 480, maxHeight: "90vh", overflowY: "auto", boxShadow: "0 8px 32px rgba(30,45,74,0.25)" }}>
            <SectionHeader>New Work Order — 3385 Bailey Rd</SectionHeader>
            <div style={{ padding: 24 }}>
              {[
                { label: "Category",           k: "category",    type: "select",   opts: categories },
                { label: "Description",         k: "description", type: "textarea" },
                { label: "Vendor",              k: "vendor",      type: "select",   opts: ["", ...allVendorNames] },
                { label: "Priority",            k: "priority",    type: "select",   opts: ["Scheduled","Standard","Urgent","Emergency"] },
                { label: "Estimated Cost ($)",  k: "cost",        type: "number" },
                { label: "Notes",               k: "notes",       type: "textarea" },
              ].map(({ label, k, type, opts }) => (
                <div key={k} style={{ marginBottom: 14 }}>
                  <label style={{ fontSize: 11, color: B.gold, display: "block", marginBottom: 4, fontWeight: 700, letterSpacing: "0.08em" }}>{label.toUpperCase()}</label>
                  {type === "select" ? (
                    <select value={form[k]} onChange={e => set(k, e.target.value)} style={{ width: "100%", background: B.cream, border: `1px solid ${B.border}`, borderRadius: 6, padding: "8px 10px", color: B.text, fontSize: 13, fontFamily: "'Inter', sans-serif" }}>
                      {opts.map(o => <option key={o}>{o}</option>)}
                    </select>
                  ) : type === "textarea" ? (
                    <textarea value={form[k]} onChange={e => set(k, e.target.value)} rows={2} style={{ width: "100%", background: B.cream, border: `1px solid ${B.border}`, borderRadius: 6, padding: "8px 10px", color: B.text, fontSize: 13, resize: "vertical", boxSizing: "border-box", fontFamily: "'Inter', sans-serif" }} />
                  ) : (
                    <input type={type} value={form[k]} onChange={e => set(k, e.target.value)} style={{ width: "100%", background: B.cream, border: `1px solid ${B.border}`, borderRadius: 6, padding: "8px 10px", color: B.text, fontSize: 13, boxSizing: "border-box", fontFamily: "'Inter', sans-serif" }} />
                  )}
                </div>
              ))}
              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={addWO} style={{ flex: 1, background: B.navy, color: B.goldLight, border: "none", borderRadius: 6, padding: "12px", fontWeight: 700, cursor: "pointer", fontSize: 14 }}>Create Work Order</button>
                <button onClick={() => setShowForm(false)} style={{ flex: 1, background: B.cream, color: B.textMid, border: `1px solid ${B.border}`, borderRadius: 6, padding: "12px", cursor: "pointer", fontSize: 14 }}>Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── PROPERTIES ────────────────────────────────────────────────────────────
const SEED_PROPERTIES = [
  {
    id: 1,
    name: "3385 Bailey Rd",
    address: "3385 Bailey Rd, Leipers Fork, TN 37014",
    owner: "",
    ownerPhone: "",
    ownerEmail: "",
    serviceLevel: "Premium",
    monthlyFee: "",
    sqft: "",
    acreage: "",
    features: ["Pool", "Pond", "Garage", "Guest Porch", "Control4", "Gas Lanterns"],
    status: "Active",
    notes: "Primary managed property. Audit checklist and vendor list on file.",
    accessCode: "",
    gateCode: "",
    alarmCode: "",
  },
];

const FEATURE_OPTIONS = ["Pool", "Spa", "Pond", "Barn", "Guest House", "Garage", "Boat Dock", "Generator", "Smart Home", "Security System", "Well Water", "Septic", "Propane", "Gas Lanterns", "Control4", "Guest Porch", "Irrigation", "Horses / Equestrian", "Recording Studio", "STR / Rental"];
const SERVICE_LEVELS = ["Essential", "Standard", "Premium", "Elite"];
const PROPERTY_STATUSES = ["Active", "Inactive", "Prospect"];
const STATUS_PROP_STYLES = {
  "Active":   { bg: "#e8f5e9", color: "#2e7d32", border: "#a5d6a7" },
  "Inactive": { bg: "#f5f5f5", color: "#757575", border: "#e0e0e0" },
  "Prospect": { bg: "#fff8e1", color: "#b45309", border: "#fde68a" },
};
const LEVEL_STYLES = {
  "Essential": { bg: B.cream,    color: B.textMid,  border: B.border },
  "Standard":  { bg: "#e3f0fb",  color: "#1565c0",  border: "#90caf9" },
  "Premium":   { bg: "#f3e8ff",  color: "#6b21a8",  border: "#d8b4fe" },
  "Elite":     { bg: "#fef9e7",  color: "#92400e",  border: "#fde68a" },
};

function FieldInput({ label, value, onChange, type = "text", placeholder = "" }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 11, color: B.gold, display: "block", marginBottom: 4, fontWeight: 700, letterSpacing: "0.08em" }}>{label.toUpperCase()}</label>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{ width: "100%", background: B.cream, border: `1px solid ${B.border}`, borderRadius: 6, padding: "8px 10px", color: B.text, fontSize: 13, boxSizing: "border-box", fontFamily: "'Inter', sans-serif" }} />
    </div>
  );
}

function PropertiesTab() {
  const [properties, setProperties] = useState(SEED_PROPERTIES);
  const [selected, setSelected] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState({ name: "", address: "", owner: "", ownerPhone: "", ownerEmail: "", serviceLevel: "Standard", monthlyFee: "", sqft: "", acreage: "", features: [], status: "Active", notes: "", accessCode: "", gateCode: "", alarmCode: "" });

  const setF = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const toggleFeature = (f) => setForm(p => ({ ...p, features: p.features.includes(f) ? p.features.filter(x => x !== f) : [...p.features, f] }));

  const openNew = () => { setForm({ name: "", address: "", owner: "", ownerPhone: "", ownerEmail: "", serviceLevel: "Standard", monthlyFee: "", sqft: "", acreage: "", features: [], status: "Active", notes: "", accessCode: "", gateCode: "", alarmCode: "" }); setEditMode(false); setShowForm(true); };
  const openEdit = (p) => { setForm({ ...p }); setEditMode(true); setShowForm(true); };

  const saveProperty = () => {
    if (!form.name) return;
    if (editMode) {
      setProperties(prev => prev.map(p => p.id === form.id ? { ...form } : p));
      setSelected(form.id);
    } else {
      const newP = { ...form, id: Date.now() };
      setProperties(prev => [...prev, newP]);
      setSelected(newP.id);
    }
    setShowForm(false);
  };

  const deleteProperty = (id) => { setProperties(prev => prev.filter(p => p.id !== id)); setSelected(null); };

  const prop = properties.find(p => p.id === selected);

  // ── Detail view ────────────────────────────────────────────────────────
  if (prop && !showForm) {
    return (
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
          <button onClick={() => setSelected(null)} style={{ background: B.cream, border: `1px solid ${B.border}`, borderRadius: 6, padding: "6px 14px", color: B.textMid, cursor: "pointer", fontSize: 13 }}>← Back</button>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, color: B.gold, fontWeight: 700, letterSpacing: "0.12em" }}>PROPERTY DETAIL</div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: B.navy, fontWeight: 700, lineHeight: 1.2 }}>{prop.name}</div>
          </div>
          <button onClick={() => openEdit(prop)} style={{ background: B.navy, color: B.goldLight, border: "none", borderRadius: 6, padding: "9px 20px", fontWeight: 700, cursor: "pointer", fontSize: 13 }}>Edit Property</button>
          <button onClick={() => deleteProperty(prop.id)} style={{ background: "#fdecea", color: "#b71c1c", border: "1px solid #ef9a9a", borderRadius: 6, padding: "9px 16px", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>Delete</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
          {/* Info */}
          <Card>
            <SectionHeader>Property Info</SectionHeader>
            <div style={{ padding: 18 }}>
              {[
                ["Address", prop.address],
                ["Acreage", prop.acreage ? `${prop.acreage} acres` : "—"],
                ["Sq Footage", prop.sqft ? `${Number(prop.sqft).toLocaleString()} sq ft` : "—"],
                ["Monthly Fee", prop.monthlyFee ? `$${Number(prop.monthlyFee).toLocaleString()}/mo` : "—"],
              ].map(([label, val]) => (
                <div key={label} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${B.border}` }}>
                  <span style={{ fontSize: 12, color: B.textLight, fontWeight: 600 }}>{label}</span>
                  <span style={{ fontSize: 13, color: B.text, fontWeight: 500 }}>{val || "—"}</span>
                </div>
              ))}
              <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                <Badge label={prop.status} styleMap={STATUS_PROP_STYLES} />
                <Badge label={prop.serviceLevel} styleMap={LEVEL_STYLES} />
              </div>
            </div>
          </Card>

          {/* Owner */}
          <Card>
            <SectionHeader>Owner Contact</SectionHeader>
            <div style={{ padding: 18 }}>
              {[
                ["Owner", prop.owner],
                ["Phone", prop.ownerPhone],
                ["Email", prop.ownerEmail],
              ].map(([label, val]) => (
                <div key={label} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${B.border}` }}>
                  <span style={{ fontSize: 12, color: B.textLight, fontWeight: 600 }}>{label}</span>
                  <span style={{ fontSize: 13, color: B.text }}>{val || "—"}</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Access */}
          <Card>
            <SectionHeader>Access & Codes</SectionHeader>
            <div style={{ padding: 18 }}>
              {[
                ["Access Code", prop.accessCode],
                ["Gate Code", prop.gateCode],
                ["Alarm Code", prop.alarmCode],
              ].map(([label, val]) => (
                <div key={label} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${B.border}` }}>
                  <span style={{ fontSize: 12, color: B.textLight, fontWeight: 600 }}>{label}</span>
                  <span style={{ fontSize: 13, color: val ? B.navy : B.textLight, fontFamily: val ? "monospace" : "inherit", fontWeight: val ? 700 : 400 }}>{val || "—"}</span>
                </div>
              ))}
              <p style={{ fontSize: 11, color: B.textLight, marginTop: 12, marginBottom: 0, fontStyle: "italic" }}>Confidential — StonePoint use only</p>
            </div>
          </Card>

          {/* Features */}
          <Card>
            <SectionHeader>Property Features</SectionHeader>
            <div style={{ padding: 18 }}>
              {prop.features.length > 0 ? (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {prop.features.map(f => (
                    <span key={f} style={{ background: B.navy, color: B.goldLight, borderRadius: 4, padding: "3px 10px", fontSize: 12, fontWeight: 600 }}>{f}</span>
                  ))}
                </div>
              ) : <span style={{ fontSize: 13, color: B.textLight }}>No features listed</span>}
            </div>
          </Card>
        </div>

        {/* Notes */}
        {prop.notes && (
          <Card>
            <SectionHeader>Notes</SectionHeader>
            <div style={{ padding: 18 }}>
              <p style={{ margin: 0, fontSize: 14, color: B.text, lineHeight: 1.6 }}>{prop.notes}</p>
            </div>
          </Card>
        )}
      </div>
    );
  }

  // ── List view ──────────────────────────────────────────────────────────
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 20 }}>
        <PageLabel sub="STONEPOINT MANAGEMENT" title="Properties" />
        <button onClick={openNew} style={{ background: B.navy, color: B.goldLight, border: "none", borderRadius: 6, padding: "10px 22px", fontWeight: 700, cursor: "pointer", fontSize: 14, marginBottom: 4 }}>+ Add Property</button>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {properties.map(p => (
          <div key={p.id} onClick={() => setSelected(p.id)}
            style={{ background: B.white, border: `1px solid ${B.border}`, borderRadius: 8, overflow: "hidden", boxShadow: "0 1px 4px rgba(30,45,74,0.07)", cursor: "pointer", transition: "box-shadow 0.15s" }}
            onMouseEnter={e => e.currentTarget.style.boxShadow = "0 4px 16px rgba(30,45,74,0.13)"}
            onMouseLeave={e => e.currentTarget.style.boxShadow = "0 1px 4px rgba(30,45,74,0.07)"}>
            <div style={{ display: "grid", gridTemplateColumns: "4px 1fr auto", alignItems: "stretch" }}>
              <div style={{ background: p.status === "Active" ? "#2e7d32" : p.status === "Prospect" ? B.gold : "#bdbdbd" }} />
              <div style={{ padding: "16px 20px", display: "grid", gridTemplateColumns: "1fr 200px 150px 130px 110px", alignItems: "center", gap: 12 }}>
                <div>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 17, color: B.navy, fontWeight: 700 }}>{p.name}</div>
                  <div style={{ fontSize: 12, color: B.textLight, marginTop: 2 }}>{p.address || "No address on file"}</div>
                </div>
                <div style={{ fontSize: 12, color: B.textMid }}>{p.owner || <span style={{ color: B.textLight, fontStyle: "italic" }}>No owner on file</span>}</div>
                <div><Badge label={p.serviceLevel} styleMap={LEVEL_STYLES} /></div>
                <div><Badge label={p.status} styleMap={STATUS_PROP_STYLES} /></div>
                <div style={{ fontSize: 14, fontWeight: 700, color: B.navy, textAlign: "right" }}>
                  {p.monthlyFee ? `$${Number(p.monthlyFee).toLocaleString()}/mo` : <span style={{ color: B.textLight, fontSize: 12, fontWeight: 400 }}>Fee TBD</span>}
                </div>
              </div>
            </div>
            {p.features.length > 0 && (
              <div style={{ padding: "8px 24px 12px", borderTop: `1px solid ${B.border}`, background: B.rowAlt, display: "flex", gap: 6, flexWrap: "wrap" }}>
                {p.features.map(f => (
                  <span key={f} style={{ background: B.cream, border: `1px solid ${B.border}`, color: B.textMid, borderRadius: 4, padding: "2px 8px", fontSize: 11, fontWeight: 600 }}>{f}</span>
                ))}
              </div>
            )}
          </div>
        ))}
        {properties.length === 0 && (
          <div style={{ background: B.white, border: `1px solid ${B.border}`, borderRadius: 8, padding: "40px 20px", textAlign: "center" }}>
            <div style={{ fontSize: 13, color: B.textLight }}>No properties added yet. Click <strong>+ Add Property</strong> to get started.</div>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "#00000088", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999 }}>
          <div style={{ background: B.white, border: `1px solid ${B.border}`, borderRadius: 8, overflow: "hidden", width: 580, maxHeight: "92vh", overflowY: "auto", boxShadow: "0 8px 32px rgba(30,45,74,0.25)" }}>
            <SectionHeader>{editMode ? "Edit Property" : "Add New Property"}</SectionHeader>
            <div style={{ padding: 24 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 16px" }}>
                <FieldInput label="Property Name" value={form.name} onChange={v => setF("name", v)} placeholder="e.g. 3385 Bailey Rd" />
                <div style={{ marginBottom: 14 }}>
                  <label style={{ fontSize: 11, color: B.gold, display: "block", marginBottom: 4, fontWeight: 700, letterSpacing: "0.08em" }}>STATUS</label>
                  <select value={form.status} onChange={e => setF("status", e.target.value)} style={{ width: "100%", background: B.cream, border: `1px solid ${B.border}`, borderRadius: 6, padding: "8px 10px", color: B.text, fontSize: 13, fontFamily: "'Inter', sans-serif" }}>
                    {PROPERTY_STATUSES.map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <FieldInput label="Address" value={form.address} onChange={v => setF("address", v)} placeholder="Full property address" />
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 16px" }}>
                <FieldInput label="Owner Name" value={form.owner} onChange={v => setF("owner", v)} />
                <FieldInput label="Owner Phone" value={form.ownerPhone} onChange={v => setF("ownerPhone", v)} type="tel" />
                <FieldInput label="Owner Email" value={form.ownerEmail} onChange={v => setF("ownerEmail", v)} type="email" />
                <div style={{ marginBottom: 14 }}>
                  <label style={{ fontSize: 11, color: B.gold, display: "block", marginBottom: 4, fontWeight: 700, letterSpacing: "0.08em" }}>SERVICE LEVEL</label>
                  <select value={form.serviceLevel} onChange={e => setF("serviceLevel", e.target.value)} style={{ width: "100%", background: B.cream, border: `1px solid ${B.border}`, borderRadius: 6, padding: "8px 10px", color: B.text, fontSize: 13, fontFamily: "'Inter', sans-serif" }}>
                    {SERVICE_LEVELS.map(l => <option key={l}>{l}</option>)}
                  </select>
                </div>
                <FieldInput label="Monthly Fee ($)" value={form.monthlyFee} onChange={v => setF("monthlyFee", v)} type="number" />
                <FieldInput label="Square Footage" value={form.sqft} onChange={v => setF("sqft", v)} type="number" />
                <FieldInput label="Acreage" value={form.acreage} onChange={v => setF("acreage", v)} type="number" />
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11, color: B.gold, display: "block", marginBottom: 8, fontWeight: 700, letterSpacing: "0.08em" }}>PROPERTY FEATURES</label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {FEATURE_OPTIONS.map(f => (
                    <div key={f} onClick={() => toggleFeature(f)}
                      style={{ background: form.features.includes(f) ? B.navy : B.cream, color: form.features.includes(f) ? B.goldLight : B.textMid, border: `1px solid ${form.features.includes(f) ? B.navy : B.border}`, borderRadius: 4, padding: "4px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer", userSelect: "none", transition: "all 0.15s" }}>
                      {f}
                    </div>
                  ))}
                </div>
              </div>

              <div style={{ borderTop: `1px solid ${B.border}`, paddingTop: 14, marginBottom: 14 }}>
                <div style={{ fontSize: 11, color: B.gold, fontWeight: 700, letterSpacing: "0.08em", marginBottom: 12 }}>ACCESS & CODES (CONFIDENTIAL)</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0 16px" }}>
                  <FieldInput label="Access Code" value={form.accessCode} onChange={v => setF("accessCode", v)} />
                  <FieldInput label="Gate Code" value={form.gateCode} onChange={v => setF("gateCode", v)} />
                  <FieldInput label="Alarm Code" value={form.alarmCode} onChange={v => setF("alarmCode", v)} />
                </div>
              </div>

              <div style={{ marginBottom: 20 }}>
                <label style={{ fontSize: 11, color: B.gold, display: "block", marginBottom: 4, fontWeight: 700, letterSpacing: "0.08em" }}>NOTES</label>
                <textarea value={form.notes} onChange={e => setF("notes", e.target.value)} rows={3}
                  style={{ width: "100%", background: B.cream, border: `1px solid ${B.border}`, borderRadius: 6, padding: "8px 10px", color: B.text, fontSize: 13, resize: "vertical", boxSizing: "border-box", fontFamily: "'Inter', sans-serif" }} />
              </div>

              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={saveProperty} style={{ flex: 1, background: B.navy, color: B.goldLight, border: "none", borderRadius: 6, padding: "12px", fontWeight: 700, cursor: "pointer", fontSize: 14 }}>
                  {editMode ? "Save Changes" : "Add Property"}
                </button>
                <button onClick={() => setShowForm(false)} style={{ flex: 1, background: B.cream, color: B.textMid, border: `1px solid ${B.border}`, borderRadius: 6, padding: "12px", cursor: "pointer", fontSize: 14 }}>Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── VENDORS ────────────────────────────────────────────────────────────────
function VendorsTab() {
  return (
    <div>
      <PageLabel sub="3385 BAILEY RD" title="Vendor Directory" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16 }}>
        {Object.entries(VENDORS).map(([trade, list]) => (
          <Card key={trade}>
            <SectionHeader>{trade}</SectionHeader>
            {list.map((v, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", padding: "12px 16px", background: i % 2 === 0 ? B.white : B.rowAlt, borderBottom: i < list.length - 1 ? `1px solid ${B.border}` : "none" }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: B.navy }}>{v.name}</div>
                  <div style={{ fontSize: 11, color: B.textLight, marginTop: 2 }}>{v.role}</div>
                </div>
                <a href={`tel:${v.phone}`} style={{ fontSize: 13, color: B.gold, textDecoration: "none", fontWeight: 700, marginTop: 2, whiteSpace: "nowrap" }}>{v.phone}</a>
              </div>
            ))}
          </Card>
        ))}
      </div>
      <div style={{ marginTop: 24, padding: "12px 0", borderTop: `1px solid ${B.border}`, display: "flex", justifyContent: "space-between" }}>
        <span style={{ fontSize: 11, color: B.textLight }}>StonePoint Management · Your Property, Our Priority</span>
        <span style={{ fontSize: 11, color: B.textLight }}>Confidential</span>
      </div>
    </div>
  );
}

// ── APP ────────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("dashboard");
  return (
    <div style={{ minHeight: "100vh", background: B.creamDark, fontFamily: "'Inter', sans-serif" }}>
      <link href={FONT_LINK} rel="stylesheet" />
      <TopBar tab={tab} setTab={setTab} />
      <div style={{ maxWidth: 1140, margin: "0 auto", padding: "32px 28px" }}>
        {tab === "dashboard"   && <DashboardTab />}
        {tab === "properties"  && <PropertiesTab />}
        {tab === "audit"       && <AuditTab />}
        {tab === "workorders"  && <WorkOrdersTab />}
        {tab === "vendors"     && <VendorsTab />}
      </div>
    </div>
  );
}
